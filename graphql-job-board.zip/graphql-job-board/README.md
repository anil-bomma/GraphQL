# GraphQL Job Board

Sample application used in the GraphQL by Example course.
